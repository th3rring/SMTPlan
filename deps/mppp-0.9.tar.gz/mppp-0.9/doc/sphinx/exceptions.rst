.. _exceptions:

Exceptions
==========

*#include <mp++/exceptions.hpp>*

.. doxygenstruct:: mppp::zero_division_error
   :members:
