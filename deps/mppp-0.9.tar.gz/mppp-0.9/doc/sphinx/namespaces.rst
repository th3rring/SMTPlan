Namespaces
==========

All the functionality of the library is included within the ``mppp`` namespace.
