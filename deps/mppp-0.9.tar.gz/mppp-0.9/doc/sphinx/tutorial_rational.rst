.. _tutorial_rational:

Rational tutorial
=================

TBD
